<div id="{{uc_id}}" class="ue_cursor-wrap" data-cursor="{{cursor_type}}">
  
  {% if uc_inside_editor == "yes" %}<div class="ue-message">Custom Cursor widget added to the page. This message shows only in Editor.</div>{% endif %}
  
  {% if cursor_type == "cursor-1" %}
    <div class="ue-custom-cursor"
        size="{{curser_trails}}"
        pause-animation="{{pause_animation}}"
        difference="{{color_difference}}"
        cursor="{{cursor}}"
        color="{{cursor_color}}"
        color-outline="{{outline_color}}"
        {% if (gradient is not empty) and (cursor_color_type == "gradient")%}gradient="{{gradient|raw}}"{% endif %}
    >
    </div>
  {% endif %}

  {% if cursor_type == "cursor-2" %}
    <div class="ue_cursor ue_cursor-item ue_cursor-item--2">
      {% if show_outer_cursor == "true" %}<div class="cursor__ball cursor__ball--big "></div>{% endif %}
      <div class="cursor__ball cursor__ball--small">
        <div class="cursor__ball--small-inner {{attention_grabber}}">
          {% if show_graphic_element == "icon" %}<div class="ue_cursor_icon">{{custom_icon_html|raw}}</div>{% endif %}
          {% if show_graphic_element == "image" %}<img src="{{cursor_image}}">{% endif %}
          {% if show_graphic_element == "text" %}<div class="ue_cursor_text">{{graphic_element_text|raw}}</div>{% endif %}
      	</div>
        </div>
    </div>
  {% endif %}
</div>