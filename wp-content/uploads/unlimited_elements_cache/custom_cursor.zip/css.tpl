#{{uc_id}}{
  min-height: 1px;
}

#{{uc_id}} .ue-message{
  padding: 10px;
  border: 1px solid grey;
  background-color: lightgrey;
  border-radius: 5px;
  font-size: 12px;
}

/* should be written without #{{uc_id}} */
.uc-mscursor-hidden{
  display:none !important;
}

/* cursor 2: custom cursor */
{% if cursor_type == "cursor-2" %}
  #{{uc_id}} .ue_cursor {
    pointer-events: none;
    opacity:1;
    transition: all 300ms ease;
  }

  #{{uc_id}} .ue_cursor.cursor-inactive {
    opacity:0;
  }

  #{{uc_id}} .cursor__ball {
    display:flex;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 1000;
    pointer-events:none;
    transform: matrix(1, 0, 0, 1, -100, -100);
  }

  #{{uc_id}} .cursor__ball--small{
    display:flex;
    align-items:center;
    justify-content:center;
  }

  #{{uc_id}} .cursor__ball--small-inner{
    display:flex;
    align-items:center;
    justify-content:center;
  }

  {% if show_graphic_element == "icon" %}
    #{{uc_id}} .cursor__ball--small svg{
       width:1em;
       height:1em;
    }
  {% endif %}

  {% if show_graphic_element == "image" %}
    #{{uc_id}} .cursor__ball--small .ue_cursor_image{
       display:flex;
    }
  {% endif %}

  {% if show_outer_cursor == "true" %}
    #{{uc_id}} .cursor__ball--big{
       {% if mix_blend_difference == "true" %}mix-blend-mode: difference;{% endif %}
    }
  {% endif %}

  {% if show_cursor == "false" %} 
    body {
      cursor: none;
    }
  {% endif %}

{% endif %}

/* attention grabber  */
{% if enable_attention_grabber == 'true' %}

	{% if attention_grabber == 'ue-floating-chat-waggle' %}
	  .ue-floating-chat-waggle{
          animation: ue-floating-chat-waggle_{{uc_id}} 5s infinite;
      }

      @keyframes ue-floating-chat-waggle_{{uc_id}} {
          0% {
              transform: none;
          }

          10% {
              transform: rotateZ(-20deg) scale(1.2);
          }

          13% {
              transform: rotateZ(25deg) scale(1.2);
          }

          15% {
              transform: rotateZ(-15deg) scale(1.2);
          }

          17% {
              transform: rotateZ(15deg) scale(1.2);
          }

          20% {
              transform: rotateZ(-12deg) scale(1.2);
          }

          22% {
              transform: rotateZ(0) scale(1.2);
          }

          25%,
          100% {
              transform: rotateZ(0) scale(1);
          }
      }
	{% endif %}

	{% if attention_grabber == 'ue-floating-chat-fade' %}
      .ue-floating-chat-fade{
          animation: ue-floating-chat-fade_{{uc_id}} 5s infinite;
      }

      @keyframes ue-floating-chat-fade_{{uc_id}} {
          5% {
              opacity: .25;
          }

          10% {
              opacity: 1;
          }

          15% {
              opacity: .25;
          }

          20%,
          100% {
              opacity: 1;
          }
      }
	{% endif %}
	
	{% if attention_grabber == 'ue-floating-chat-blink' %}
      .ue-floating-chat-blink {
          animation: ue-floating-chat-blink_{{uc_id}} 1.33s ease-out infinite;
      }

      @keyframes ue-floating-chat-blink_{{uc_id}} {
          0% {
              opacity: 1;
          }

          20% {
              opacity: .5;
          }

          100% {
              opacity: 1;
          }
      }
	{% endif %}

	{% if attention_grabber == 'ue-floating-chat-grow' %}
      #{{uc_id}} .ue-floating-chat-grow{
          animation: ue-floating-chat-grow_{{uc_id}} .4s ease infinite alternate;
      }

      @keyframes ue-floating-chat-grow_{{uc_id}} {
          0% {
              transform: scale(1);
          }

          100% {
              transform: scale(1.1);
          }
      }
	{% endif %}

	{% if attention_grabber == 'ue-floating-chat-bounce' %}
      #{{uc_id}} .ue-floating-chat-bounce {
          animation: ue-floating-chat-bounce_{{uc_id}} 5s infinite cubic-bezier(.84, -.54, .31, 1.19);
      }

      @keyframes ue-floating-chat-bounce_{{uc_id}} {
          0% {
              margin-top: 0;
          }

          10% {
              margin-top: -1em;
          }

          100%,
          20% {
              margin-top: 0;
          }
      }
	{% endif %}

	{% if attention_grabber == 'ue-floating-chat-spin' %}
      .ue-floating-chat-spin {
          animation: ue-floating-chat-spin_{{uc_id}} 5s infinite cubic-bezier(.56, -.35, .22, 1.5);
      }

      @keyframes ue-floating-chat-spin_{{uc_id}} {
          10% {
              transform: rotateZ(-20deg);
              animation-timing-function: ease;
          }

          100%,
          20% {
              transform: rotateZ(360deg);
          }
      }
	{% endif %}

	{% if attention_grabber == 'ue-floating-chat-pulse' %}
      .ue-floating-chat-pulse:after {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          bottom: 0;
          right: 0;
          border-radius: 50%;
          animation: ue-floating-chat-pulse_{{uc_id}} 2s 1.3s ease-out infinite;
      }

      .ue-floating-chat-pulse:before {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          bottom: 0;
          right: 0;
          border-radius: 50%;
          animation: ue-floating-chat-pulse_{{uc_id}} 2s .8s ease-out infinite;
      }

      @keyframes ue-floating-chat-pulse_{{uc_id}} {
          0% {
              transform: scale(1);
              box-shadow: 0 0 2px {{pulse_color}}, inset 0 0 1px {{pulse_color}};
          }

          95% {
              box-shadow: 0 0 50px transparent, inset 0 0 30px transparent;
          }

          100% {
              transform: scale(2.25);
          }
      }
	{% endif %}

	{% if attention_grabber == 'ue-floating-chat-shine' %}
	  
      .ue-floating-chat-shine {
          overflow: hidden;
          position: relative;
      }
      .ue-floating-chat-shine::after {
          animation: ue-floating-chat-shine_{{uc_id}} 5s infinite;
          content: '';
          position: absolute;
          z-index: 1001;
          top: 0;
          right: 0;
          bottom: 0;
          left: 0;
          background: linear-gradient(to bottom, transparent, rgba(255, 255, 255, .2) 50%, transparent);
          transform: rotateZ(60deg) translate(0, 5em);
      }

      @keyframes ue-floating-chat-shine_{{uc_id}} {
          20%,
          100% {
              transform: rotateZ(60deg) translate(0, -80px);
          }
      }
    {% endif %}
{% endif %}
/* end attention grabber */
/* end cursor 2: custom cursor */